import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attractions',
  templateUrl: './attractions.page.html',
  styleUrls: ['./attractions.page.scss'],
})
export class AttractionsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
