import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arts',
  templateUrl: './arts.page.html',
  styleUrls: ['./arts.page.scss'],
})
export class ArtsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
