import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-front-page',
  templateUrl: './front-page.page.html',
  styleUrls: ['./front-page.page.scss'],
})
export class FrontPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
